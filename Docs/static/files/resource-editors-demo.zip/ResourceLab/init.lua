local Dora = require("Dora")
local particle = Dora.Particle("fire.par")
particle.scaleX = 3
particle.scaleY = 3
particle:addTo(Dora.Director.entry)
particle:start()

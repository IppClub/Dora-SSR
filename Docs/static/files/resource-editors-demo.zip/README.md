# Resource editor walkthrough examples / 资源编辑器演示工程

Upload this ZIP to Dora Workspace, unzip it, and open a project below. / 上传到 Dora 工作空间并解压，然后打开下列项目。

- ResourceLab: open fire.par to edit its Magic preset; Run init.lua to see the saved particles. / 打开 fire.par 编辑粒子；运行 init.lua 查看保存后的效果。
- AnimationLab: open xiaoli.model; select wave to inspect its two keys. Run init.lua to play it. / 打开 xiaoli.model，选择 wave 查看两帧动画；运行 init.lua 播放。
- PhysicsLab: open scene.b.lua to test the ball and ground; Run init.lua to load the resource with BodyEx. / 打开 scene.b.lua 测试圆形与地面；运行 init.lua 通过 BodyEx 加载。

The model art and base resources come from IppClub/Dora-Example. The original project license is included. / 模型图片和基础资源来自 IppClub/Dora-Example，附原项目许可证。

local Dora = require("Dora")
local model = Dora.Model("xiaoli.model")
model:addTo(Dora.Director.entry)
model:play("wave", true)

local Dora = require("Dora")
local BodyEx = require("BodyEx")
local world = Dora.PhysicsWorld()
world.showDebug = true
world:addTo(Dora.Director.entry)
local assembly = BodyEx("scene.b.lua", world)
if assembly then assembly:addTo(world) end

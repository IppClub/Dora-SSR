return {
	"Array",
	{"Phyx.Rect","ground","Static",{0,-160},0,{0,0},{500,30},1,0.4,0,0,0,false,{0,-10},false,false,0,false,"",{0,0},1},
	{"Phyx.Disk","ball","Dynamic",{0,115},0,{0,0},48,1,0.4,0,0,0,false,{0,-10},false,false,0,false,"",{0,0},1}
}